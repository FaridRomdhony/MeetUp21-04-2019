<?php

if(is_array($_FILES)) {
	if(is_uploaded_file($_FILES['files']['tmp_name'])) {
		$sourcePath = $_FILES['files']['tmp_name'];
		$targetPath = "files/".$_POST['nama'].$_FILES['files']['name'];
		if(move_uploaded_file($sourcePath,$targetPath)) {
			$dtArr = array(
				'nama' => $_POST['nama'],
				'file' => $targetPath
			);
			$json = json_encode($dtArr);
			echo $json;
		}else{
			echo "Ups Something wrong";
		}
	}
}

?>