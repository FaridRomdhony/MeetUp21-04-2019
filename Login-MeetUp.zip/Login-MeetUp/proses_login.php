<?php
if (empty($_POST['username']) || empty($_POST['password'])) {
	echo "Username dan password Harus Diisi";
}else{
	if ($_POST['username']=='admin' && $_POST['password'] =='admin') {
		echo "Login Sukses";
	}else{
		echo "Username atau Password Salah";
	}
}
die;
?>